// netlify/functions/finnhub-proxy.js
var FINNHUB_KEY = process.env.FINNHUB_API_KEY;
var BASE = "https://finnhub.io/api/v1";
var cache = {};
function getCached(key, ttlMs) {
  const entry = cache[key];
  if (entry && Date.now() - entry.ts < ttlMs) return entry.data;
  return null;
}
function setCache(key, data) {
  cache[key] = { data, ts: Date.now() };
}
async function fetchYahooCandles(symbol, fromTs, toTs) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?period1=${fromTs}&period2=${toTs}&interval=1d`;
  const resp = await fetch(url, {
    headers: { "User-Agent": "Mozilla/5.0" }
  });
  if (!resp.ok) return null;
  const json = await resp.json();
  const result = json?.chart?.result?.[0];
  if (!result) return null;
  const timestamps = result.timestamp;
  const quotes = result.indicators?.quote?.[0];
  if (!timestamps || !quotes) return null;
  return {
    s: "ok",
    c: quotes.close.filter((v) => v !== null),
    h: quotes.high.filter((v) => v !== null),
    l: quotes.low.filter((v) => v !== null),
    o: quotes.open.filter((v) => v !== null),
    v: quotes.volume.filter((v) => v !== null),
    t: timestamps.filter((_, i) => quotes.close[i] !== null)
  };
}
async function fetchYahooIntraday(symbol) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=5m&range=1d`;
  const resp = await fetch(url, {
    headers: { "User-Agent": "Mozilla/5.0" }
  });
  if (!resp.ok) return null;
  const json = await resp.json();
  const result = json?.chart?.result?.[0];
  if (!result) return null;
  const timestamps = result.timestamp;
  const quotes = result.indicators?.quote?.[0];
  if (!timestamps || !quotes) return null;
  return {
    s: "ok",
    c: timestamps.map((_, i) => quotes.close[i]).filter((v) => v !== null),
    h: timestamps.map((_, i) => quotes.high[i]).filter((v) => v !== null),
    l: timestamps.map((_, i) => quotes.low[i]).filter((v) => v !== null),
    o: timestamps.map((_, i) => quotes.open[i]).filter((v) => v !== null),
    v: timestamps.map((_, i) => quotes.volume[i]).filter((v) => v !== null),
    t: timestamps.filter((_, i) => quotes.close[i] !== null),
    intraday: true
  };
}
exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (!FINNHUB_KEY) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: "FINNHUB_API_KEY not configured" }) };
  }
  const params = event.queryStringParameters || {};
  const { endpoint, symbol, from, to, resolution } = params;
  if (!endpoint) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "endpoint parameter required (quote, candles, profile)" }) };
  }
  if (!symbol && endpoint !== "batch") {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "symbol parameter required" }) };
  }
  try {
    let url, cacheKey, ttl;
    switch (endpoint) {
      case "quote":
        cacheKey = `quote:${symbol}`;
        ttl = 2 * 60 * 1e3;
        url = `${BASE}/quote?symbol=${symbol}&token=${FINNHUB_KEY}`;
        break;
      case "candles": {
        const fromTs = from || Math.floor(Date.now() / 1e3) - 45 * 86400;
        const toTs = to || Math.floor(Date.now() / 1e3);
        cacheKey = `candles:${symbol}:${fromTs}`;
        ttl = 30 * 60 * 1e3;
        const cached2 = getCached(cacheKey, ttl);
        if (cached2) {
          return { statusCode: 200, headers, body: JSON.stringify(cached2) };
        }
        const fhUrl = `${BASE}/stock/candle?symbol=${symbol}&resolution=D&from=${fromTs}&to=${toTs}&token=${FINNHUB_KEY}`;
        const fhResp = await fetch(fhUrl);
        if (fhResp.ok) {
          const fhData = await fhResp.json();
          if (fhData.s === "ok") {
            setCache(cacheKey, fhData);
            return { statusCode: 200, headers, body: JSON.stringify(fhData) };
          }
        }
        const yahooData = await fetchYahooCandles(symbol, fromTs, toTs);
        if (yahooData && yahooData.c.length > 0) {
          setCache(cacheKey, yahooData);
          return { statusCode: 200, headers, body: JSON.stringify(yahooData) };
        }
        return { statusCode: 200, headers, body: JSON.stringify({ s: "no_data" }) };
      }
      case "intraday": {
        cacheKey = `intraday:${symbol}`;
        ttl = 2 * 60 * 1e3;
        const intradayCached = getCached(cacheKey, ttl);
        if (intradayCached) {
          return { statusCode: 200, headers, body: JSON.stringify(intradayCached) };
        }
        const intradayData = await fetchYahooIntraday(symbol);
        if (intradayData && intradayData.c.length > 0) {
          setCache(cacheKey, intradayData);
          return { statusCode: 200, headers, body: JSON.stringify(intradayData) };
        }
        return { statusCode: 200, headers, body: JSON.stringify({ s: "no_data" }) };
      }
      case "profile":
        cacheKey = `profile:${symbol}`;
        ttl = 24 * 60 * 60 * 1e3;
        url = `${BASE}/stock/profile2?symbol=${symbol}&token=${FINNHUB_KEY}`;
        break;
      default:
        return { statusCode: 400, headers, body: JSON.stringify({ error: `Unknown endpoint: ${endpoint}` }) };
    }
    const cached = getCached(cacheKey, ttl);
    if (cached) {
      return { statusCode: 200, headers, body: JSON.stringify(cached) };
    }
    const resp = await fetch(url);
    if (!resp.ok) {
      return { statusCode: resp.status, headers, body: JSON.stringify({ error: `Finnhub returned ${resp.status}` }) };
    }
    const data = await resp.json();
    setCache(cacheKey, data);
    return { statusCode: 200, headers, body: JSON.stringify(data) };
  } catch (err) {
    console.error("Proxy error:", err);
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
  }
};
